<html><head><meta charset="utf-8"/></head><body>
<h1>JQuery Samples</h1>
<ul>
    <li><a href="dom-01.htm">dom-01.htm</a> - getElementById</li>
    <li><a href="dom-02.htm">dom-02.htm</a> - onclick and getElementById</li>
    <li><a href="dom-03.htm">dom-03.htm</a> - Adding tags</li>
</ul>
<ul>
    <li><a href="jq-01.htm">jq-01.htm</a> - document ready</li>
    <li><a href="jq-02.htm">jq-02.htm</a> - resize event</li>
    <li><a href="jq-03.htm">jq-03.htm</a> - onclick event</li>
    <li><a href="jq-04.htm">jq-04.htm</a> - adding to the DOM</li>
</ul>
