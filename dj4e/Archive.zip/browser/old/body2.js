console.log('Parsing body2.js');
