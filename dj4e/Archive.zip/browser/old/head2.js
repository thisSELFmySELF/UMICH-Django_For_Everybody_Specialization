console.log('Parsing head2.js');
