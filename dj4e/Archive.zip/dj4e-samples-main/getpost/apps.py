from django.apps import AppConfig


class GetpostConfig(AppConfig):
    name = 'getpost'
