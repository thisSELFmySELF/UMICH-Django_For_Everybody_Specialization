from django.apps import AppConfig


class BookmanyConfig(AppConfig):
    name = 'bookmany'
