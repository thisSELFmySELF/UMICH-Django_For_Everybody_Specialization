from django.apps import AppConfig

class RouteConfig(AppConfig):
    name = 'route'
