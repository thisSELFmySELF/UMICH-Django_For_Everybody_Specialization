from django.apps import AppConfig


class WellConfig(AppConfig):
    name = 'well'
