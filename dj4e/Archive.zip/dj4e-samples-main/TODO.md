
Write sample for django-ckeditor

Protect views for staff only


