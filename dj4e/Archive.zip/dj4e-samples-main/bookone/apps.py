from django.apps import AppConfig


class BookoneConfig(AppConfig):
    name = 'bookone'
