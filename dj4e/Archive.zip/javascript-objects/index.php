<h1>Javascript Objects</h1>
<ul>
<li><a href="js-01.htm">js-01.htm</a> - Make and use a Party Animal class</li>
<li><a href="js-03.htm">js-03.htm</a> - PartyAnimal class with constructor message</li>
<li><a href="js-04.htm">js-04.htm</a> - PartyAnimal class with constructor parameters</li>
<li><a href="js-05.htm">js-05.htm</a> - Array/Object syntax equivalence</li>
<li><a href="js-06.htm">js-06.htm</a> - First class function / method after the fact</li>
<li><a href="js-07.htm">js-07.htm</a> - Iterating over object attributes</li>
<li><a href="js-08.htm">js-08.htm</a> - Iterating over attributes and methods</li>
<li><a href="js-09.htm">js-09.htm</a> - Types of attributes and methods</li>
</ul>
