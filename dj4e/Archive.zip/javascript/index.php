<p>View developer console for these examples</p>
<ul>
<li><a href="js-01.htm">js-01.htm</a> - document.write()</li>
<li><a href="js-02.htm">js-02.htm</a> - alert()</li>
<li><a href="js-03.htm">js-03.htm</a> - onclick=</li>
<li><a href="js-04.htm">js-04.htm</a> - src=</li>
<li><a href="js-05.htm">js-05.htm</a> - Syntax errors</li>
<li><a href="js-06.htm">js-06.htm</a> - console.log()</li>
<li><a href="js-07.htm">js-07.htm</a> - white space</li>
<li><a href="js-08.htm">js-08.htm</a> - new lines</li>
</ul><ul>
<li><a href="js-09.htm">js-09.htm</a> - functions</li>
<li><a href="js-10.htm">js-10.htm</a> - global scope</li>
<li><a href="js-11.htm">js-11.htm</a> - var - local scope</li>
</ul><ul>
<li><a href="js-12.htm">js-12.htm</a> - conditional (if) </li>
<li><a href="js-13.htm">js-13.htm</a> - multi-way if</li>
<li><a href="js-14.htm">js-14.htm</a> - while loop </li>
<li><a href="js-15.htm">js-15.htm</a> - object "associative array"</li>
<li><a href="js-16.htm">js-16.htm</a> - Counted loop</li>
<li><a href="js-17.htm">js-17.htm</a> - Loop and break</li>
<li><a href="js-18.htm">js-18.htm</a> - Loop and continue</li>
<li><a href="js-19.htm">js-19.htm</a> - Try / catch / finally </li>
</ul>
